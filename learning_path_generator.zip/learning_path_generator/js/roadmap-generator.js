/**
 * roadmap-generator.js
 * Builds personalised roadmap data objects from user profile.
 * No DOM side-effects — returns a plain data structure.
 */

/**
 * Detect topic category.
 * @param {string} t  topic string
 * @returns {{ isCode: boolean, isData: boolean, isLang: boolean }}
 */
function detectCategory(t) {
  return {
    isCode: /react|javascript|python|coding|programming|web|app|dev|node|typescript|vue|angular|swift|flutter|java|rust|golang/i.test(t),
    isData: /data|machine learning|analytics|sql|statistics|tableau/i.test(t),
    isLang: /spanish|french|german|japanese|mandarin|chinese|arabic|italian|portuguese/i.test(t)
  };
}

/**
 * Generate a structured learning roadmap.
 * @param {string} topic
 * @param {string} level
 * @param {string} hours   e.g. "5-7"
 * @param {string} goal    e.g. "get a job"
 * @returns {object}
 */
function generateRoadmap(topic, level, hours, goal) {
  const t = topic;
  const { isCode, isData, isLang } = detectCategory(t);
  const weeksMap = { '2-3': 16, '5-7': 12, '10-15': 8, '20+': 6 };
  const totalWeeks = weeksMap[hours] || 12;
  const w    = totalWeeks;
  const p1end = Math.round(w * 0.33);
  const p2end = Math.round(w * 0.66);

  const insights = [
    `The fastest way to learn ${t} is to build something real from day one — theory alone never sticks.`,
    `Every expert at ${t} was once exactly where you are. Consistency over weeks beats cramming every time.`,
    `Learning ${t} is a skill, not a destination. The goal is to know enough to build what you want.`,
    `The best ${t} learners spend 60% of their time doing, not watching. Always have a project running.`
  ];
  const insight = insights[Math.floor(Math.random() * insights.length)];

  let phases;

  // ── CODING ────────────────────────────────────────────────────────────────
  if (isCode) {
    phases = [
      {
        phase: 1, title: `Foundations`, duration: `Weeks 1-${p1end}`,
        objective: `Understand how ${t} works and write your first real code`,
        tasks: [
          { title: `${t} crash course`,        type: `video`,   duration: `2 hrs`,   resource: `Search "${t} full course for beginners" on YouTube`,    tip: `Code along — pause and type every example yourself instead of just watching.` },
          { title: `Core concepts deep-read`,  type: `article`, duration: `1.5 hrs`, resource: `Official ${t} documentation — Getting Started section`,  tip: `Bookmark the docs. You will return here constantly as you build.` },
          { title: `Build your first mini project`, type: `project`, duration: `3 hrs`, resource: `A simple counter, calculator, or to-do list`,         tip: `Keep it tiny. The goal is to ship something, not impress anyone.` },
          { title: `Fundamentals quiz`,         type: `quiz`,    duration: `30 min`,  resource: `Create flashcards on Anki or quiz yourself on paper`,   tip: `What you get wrong is exactly what you need to study next.` }
        ]
      },
      {
        phase: 2, title: `Core Skills`, duration: `Weeks ${p1end+1}-${p2end}`,
        objective: `Apply concepts to real problems and build confidence`,
        tasks: [
          { title: `Intermediate tutorial series`, type: `video`,   duration: `3 hrs`, resource: `"${t} intermediate tutorial" on YouTube or freeCodeCamp`, tip: `Start a side project alongside the tutorial and apply each concept as you learn it.` },
          { title: `Read real-world code`,        type: `article`, duration: `1 hr`,  resource: `Browse GitHub for beginner-friendly open source projects in ${t}`, tip: `You do not need to understand everything. Look for patterns.` },
          { title: `Build a functional app`,      type: `project`, duration: `5 hrs`, resource: `A weather app, recipe finder, or task manager using a free API`, tip: `Use a real public API — it makes the project feel alive and teaches real-world skills.` },
          { title: `Debugging practice`,          type: `quiz`,    duration: `1 hr`,  resource: `Intentionally break your project and fix it`, tip: `Debugging is 50% of real dev work. Get comfortable with error messages now.` }
        ]
      },
      {
        phase: 3,
        title: goal === `get a job` ? `Portfolio and Job Prep` : goal === `pass an exam` ? `Exam Preparation` : `Capstone Project`,
        duration: `Weeks ${p2end+1}-${w}`,
        objective: goal === `get a job` ? `Build a portfolio and prepare for technical interviews` : `Ship a complete project you are proud to show`,
        tasks: [
          { title: `Plan your capstone project`, type: `project`, duration: `1 hr`,  resource: `Write a one-page spec: what it does, who uses it, what it looks like`, tip: `Tiny scope. One core feature done beats five features half-finished every time.` },
          { title: `Build and deploy`,            type: `project`, duration: `8 hrs`, resource: `Deploy on Vercel, Netlify, or GitHub Pages`, tip: `Deploy early — even a broken version online is more motivating than a perfect local build.` },
          { title: `Code review and refactor`,    type: `article`, duration: `2 hrs`, resource: `Re-read your own code then ask Claude to review it`, tip: `Look for repetition you can extract into a reusable component or function.` },
          { title: `Final self-assessment`,       type: `quiz`,    duration: `45 min`, resource: `Write down 10 things you can now do that you could not before`, tip: `This is your proof of progress — save it and look back at it when you doubt yourself.` }
        ]
      }
    ];

  // ── DATA ──────────────────────────────────────────────────────────────────
  } else if (isData) {
    phases = [
      {
        phase: 1, title: `Data Fundamentals`, duration: `Weeks 1-${p1end}`,
        objective: `Master the core tools and statistical thinking`,
        tasks: [
          { title: `${t} fundamentals course`, type: `video`,   duration: `3 hrs`,  resource: `Kaggle free courses (kaggle.com/learn) — completely free and excellent`, tip: `Kaggle courses are the best free resource in this space. Start there immediately.` },
          { title: `Statistics basics`,        type: `article`, duration: `2 hrs`,  resource: `StatQuest with Josh Starmer on YouTube`, tip: `Watch at 1.25x. Josh explains complex stats more clearly than any textbook.` },
          { title: `First dataset analysis`,   type: `project`, duration: `3 hrs`,  resource: `Download a dataset from Kaggle and explore it`, tip: `Ask 3 questions of the data before you start. Then answer them.` },
          { title: `Tools quiz`,               type: `quiz`,    duration: `30 min`, resource: `Test yourself on key concepts and syntax`, tip: `Active recall beats re-reading every single time.` }
        ]
      },
      {
        phase: 2, title: `Applied Analysis`, duration: `Weeks ${p1end+1}-${p2end}`,
        objective: `Build real analytical skills on real datasets`,
        tasks: [
          { title: `Intermediate data techniques`, type: `video`,   duration: `4 hrs`,  resource: `Corey Schafer Python tutorials or Luke Barousse SQL course on YouTube`, tip: `Follow along in your own notebook, not the instructor notebook.` },
          { title: `Read a data case study`,       type: `article`, duration: `1.5 hrs`, resource: `Towards Data Science (towardsdatascience.com)`, tip: `Notice how professionals frame questions before diving into data.` },
          { title: `End-to-end project`,           type: `project`, duration: `6 hrs`,  resource: `Pick a Kaggle competition dataset and analyse it fully`, tip: `Document every step. Your write-up is as important as your code.` },
          { title: `Peer review`,                  type: `quiz`,    duration: `1 hr`,   resource: `Post your analysis on Kaggle or share with a study group`, tip: `Feedback from others catches blind spots faster than self-review.` }
        ]
      },
      {
        phase: 3, title: `Portfolio Project`, duration: `Weeks ${p2end+1}-${w}`,
        objective: `Complete a showcase project that demonstrates real skill`,
        tasks: [
          { title: `Choose your portfolio project`,      type: `project`, duration: `1 hr`,  resource: `Pick a dataset that genuinely interests you`, tip: `Passion for the topic shows in the quality of questions you ask.` },
          { title: `Full analysis and visualisation`,    type: `project`, duration: `8 hrs`, resource: `Tableau Public, matplotlib, or Power BI for visuals`, tip: `A chart that tells a story beats ten charts that just describe data.` },
          { title: `Write up your findings`,             type: `article`, duration: `2 hrs`, resource: `Publish on Kaggle, Medium, or a personal site`, tip: `Writing forces clarity of thought. If you cannot explain it simply, keep studying.` },
          { title: `Final review`,                      type: `quiz`,    duration: `1 hr`,  resource: `List what you would do differently and what you learned`, tip: `This retrospective is what separates professionals from beginners.` }
        ]
      }
    ];

  // ── LANGUAGE ──────────────────────────────────────────────────────────────
  } else if (isLang) {
    phases = [
      {
        phase: 1, title: `Core Vocabulary`, duration: `Weeks 1-${p1end}`,
        objective: `Build a foundation of 500 words and basic grammar`,
        tasks: [
          { title: `Start a daily Duolingo habit`,  type: `video`,   duration: `15 min/day`,  resource: `Duolingo (free) — set a 15-minute daily streak goal`, tip: `Consistency beats volume. 15 minutes every day beats 3 hours on Sunday.` },
          { title: `Top 500 words flashcards`,      type: `article`, duration: `1 hr setup`,  resource: `Anki with a pre-made frequency list deck`, tip: `The top 500 words cover 75% of everyday conversation.` },
          { title: `First conversation attempt`,    type: `project`, duration: `30 min`,      resource: `italki.com for a community tutor or a language exchange app`, tip: `Be terrible on purpose. Early embarrassment accelerates learning fast.` },
          { title: `Pronunciation quiz`,            type: `quiz`,    duration: `30 min`,      resource: `Forvo.com — hear native speakers pronounce any word`, tip: `Pronunciation habits formed early are hard to break. Get them right now.` }
        ]
      },
      {
        phase: 2, title: `Speaking and Listening`, duration: `Weeks ${p1end+1}-${p2end}`,
        objective: `Hold basic conversations and understand spoken language`,
        tasks: [
          { title: `Immersion listening practice`, type: `video`,   duration: `30 min/day`, resource: `YouTube channels for ${t} learners or TV shows with subtitles`, tip: `Watch content made for native speakers. Your brain adjusts faster than you think.` },
          { title: `Grammar deep-dive`,            type: `article`, duration: `2 hrs`,      resource: `A grammar reference book or free grammar site for ${t}`, tip: `Learn grammar in context, not isolation. Always attach a rule to a real example.` },
          { title: `Weekly tutor session`,         type: `project`, duration: `1 hr/week`,  resource: `italki.com or Preply for affordable tutors`, tip: `Prepare 3 topics before each session so you do not waste time deciding what to practise.` },
          { title: `Comprehension quiz`,           type: `quiz`,    duration: `30 min`,     resource: `Watch a short video without subtitles and write what you understood`, tip: `The discomfort is the point. This is exactly what builds real comprehension.` }
        ]
      },
      {
        phase: 3, title: `Fluency Push`, duration: `Weeks ${p2end+1}-${w}`,
        objective: `Reach conversational confidence on everyday topics`,
        tasks: [
          { title: `Daily journaling in target language`, type: `project`, duration: `15 min/day`, resource: `Write 5 sentences about your day, use italki for corrections`, tip: `Writing forces you to produce language, not just recognise it.` },
          { title: `Read a short text daily`,            type: `article`, duration: `20 min/day`, resource: `News in Slow podcast or a children book in the language`, tip: `Look up only the words that block understanding. Do not translate everything.` },
          { title: `Conversation challenge`,             type: `project`, duration: `1 hr/week`,  resource: `Commit to 30-minute conversations with no English allowed`, tip: `Describing a word you do not know is a superpower. Practise working around gaps.` },
          { title: `Final fluency self-test`,           type: `quiz`,    duration: `30 min`,      resource: `Record yourself speaking for 5 minutes on a random topic and listen back`, tip: `Compare to week 1. The difference will motivate you more than anything else.` }
        ]
      }
    ];

  // ── GENERIC ───────────────────────────────────────────────────────────────
  } else {
    phases = [
      {
        phase: 1, title: `Foundations`, duration: `Weeks 1-${p1end}`,
        objective: `Understand the core principles of ${t}`,
        tasks: [
          { title: `Introduction to ${t}`,       type: `video`,   duration: `2 hrs`,  resource: `Search "${t} beginner course" on YouTube or Coursera`, tip: `Take notes by hand — it forces you to process the content, not just consume it.` },
          { title: `Read the fundamentals`,       type: `article`, duration: `1.5 hrs`, resource: `Wikipedia overview plus the top search results for "${t} basics"`, tip: `Read for understanding, not completion. Slow down on confusing sections.` },
          { title: `First practical exercise`,    type: `project`, duration: `2 hrs`,  resource: `Apply what you have learned to a small real-world task`, tip: `Do not wait until you feel ready. Starting imperfectly beats not starting.` },
          { title: `Self-quiz on basics`,         type: `quiz`,    duration: `30 min`, resource: `Write 10 questions and answer them from memory`, tip: `What you cannot recall is exactly what you need to study.` }
        ]
      },
      {
        phase: 2, title: `Building Skills`, duration: `Weeks ${p1end+1}-${p2end}`,
        objective: `Apply concepts and develop real competence`,
        tasks: [
          { title: `Intermediate course or book`, type: `video`,   duration: `4 hrs`,  resource: `Coursera, Udemy, or a well-reviewed book on ${t}`, tip: `Apply each concept to your own project as you learn it — not after.` },
          { title: `Study real examples`,         type: `article`, duration: `2 hrs`,  resource: `Find 3 case studies or examples of excellent work in ${t}`, tip: `Analyse what makes them good. Reverse-engineer the principles behind them.` },
          { title: `Substantial project`,         type: `project`, duration: `5 hrs`,  resource: `Build or create something that uses multiple skills together`, tip: `Ambitious but achievable. Stretch yourself without overwhelming yourself.` },
          { title: `Mid-point assessment`,        type: `quiz`,    duration: `45 min`, resource: `Test yourself against your original learning objectives`, tip: `Honest self-assessment is the fastest feedback loop available to you.` }
        ]
      },
      {
        phase: 3, title: `Mastery and Goal`, duration: `Weeks ${p2end+1}-${w}`,
        objective: `Achieve your goal: ${goal}`,
        tasks: [
          { title: `Advanced techniques`,  type: `video`,   duration: `3 hrs`, resource: `Advanced ${t} content — expert talks or masterclasses`, tip: `Focus on depth over breadth. Go deep on the 20% that matters most.` },
          { title: `Expert resources`,     type: `article`, duration: `2 hrs`, resource: `Industry blogs, research papers, or expert interviews on ${t}`, tip: `Reading what practitioners actually do beats any course.` },
          { title: `Capstone project`,     type: `project`, duration: `8 hrs`, resource: `Your best work — something you are proud to show`, tip: `This is the thing you point to when someone asks what you can do.` },
          { title: `Final review`,         type: `quiz`,    duration: `1 hr`,  resource: `Compare where you are now to where you started`, tip: `Document your progress. You have earned it.` }
        ]
      }
    ];
  }

  return { title: `${topic} Learning Path`, totalWeeks, insight, phases };
}

/**
 * Emergency fallback roadmap (used if generateRoadmap somehow fails).
 */
function getFallbackRoadmap(topic, level) {
  return {
    title: `${topic} Learning Path`,
    totalWeeks: 12,
    summary: `A structured ${level} path to master ${topic}.`,
    insight: "Every expert was once a beginner. The key is consistent daily practice.",
    phases: [
      {
        phase: 1, title: "Foundations", duration: "Weeks 1-4",
        objective: "Build a solid base understanding",
        tasks: [
          { title: `Introduction to ${topic}`, type: "video",   duration: "2 hrs",  resource: "YouTube crash course",        tip: "Watch 2x speed, pause to take notes" },
          { title: "Core concepts overview",   type: "article", duration: "1 hr",   resource: "Official documentation",      tip: "Bookmark for reference" },
          { title: "Beginner quiz",            type: "quiz",    duration: "30 min", resource: "Quizlet flashcards",          tip: "Test yourself before moving on" },
          { title: "First small project",      type: "project", duration: "3 hrs",  resource: "Build a simple demo",         tip: "Getting stuck is part of learning" }
        ]
      },
      {
        phase: 2, title: "Building Skills", duration: "Weeks 5-8",
        objective: "Apply concepts in real scenarios",
        tasks: [
          { title: "Intermediate tutorial series", type: "video",   duration: "4 hrs",  resource: "Udemy / freeCodeCamp",        tip: "Code along, don't just watch" },
          { title: "Deep-dive article",            type: "article", duration: "1.5 hrs", resource: "Medium / dev.to",            tip: "Take implementation notes" },
          { title: "Mid-level project",            type: "project", duration: "6 hrs",  resource: "Build a functional app",      tip: "Push to GitHub for portfolio" },
          { title: "Practice quiz",               type: "quiz",    duration: "45 min", resource: "LeetCode / Kahoot",           tip: "Review wrong answers carefully" }
        ]
      },
      {
        phase: 3, title: "Mastery & Real Projects", duration: "Weeks 9-12",
        objective: "Achieve your goal with advanced knowledge",
        tasks: [
          { title: "Advanced concepts deep-dive", type: "video",   duration: "3 hrs",  resource: "Conference talks / expert courses", tip: "Focus on patterns, not syntax" },
          { title: "Industry best practices",     type: "article", duration: "2 hrs",  resource: "Engineering blogs",               tip: "Read what pros actually do" },
          { title: "Capstone project",            type: "project", duration: "10 hrs", resource: "Build something for your portfolio", tip: "This is your proof of skill" },
          { title: "Final assessment",            type: "quiz",    duration: "1 hr",   resource: "Mock interview / certification prep", tip: "Simulate real conditions" }
        ]
      }
    ]
  };
}

/** Simple promise-based sleep. */
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
