/**
 * main.js
 * Entry point — initialises event listeners and orchestrates the generation flow.
 */

// ── INIT ──────────────────────────────────────────────────────────────────────

// Goal chip selection
document.querySelectorAll('.chip').forEach(c => {
  c.onclick = () => {
    document.querySelectorAll('.chip').forEach(x => x.classList.remove('selected'));
    c.classList.add('selected');
    selectedGoal = c.dataset.val;
  };
});

// ── GENERATION FLOW ───────────────────────────────────────────────────────────

/**
 * Called when the user clicks "Generate My Learning Path".
 * Validates input, collects profile, transitions to agents screen,
 * animates the agent cards, then builds and renders the roadmap.
 */
async function startGeneration() {
  const topic = document.getElementById('topic-input').value.trim();
  if (!topic) { alert('Please enter a topic!'); return; }

  const level = document.getElementById('level-select').value;
  const hours = document.getElementById('hours-select').value;
  const goal  = selectedGoal || 'personal growth';

  userProfile = { topic, level, hours, goal };
  showScreen('screen-agents');

  // ── Animate agents sequentially ──
  await sleep(400);
  setAgent(1, 'working', 'Analyzing skill level');
  setProgress(15);
  await sleep(800);
  setLog('Skill Assessor: profiling ' + level + ' learner for ' + topic);
  setAgent(1, 'done', 'Skill profile complete');

  setAgent(2, 'working', 'Designing phases');
  setProgress(35);
  await sleep(600);
  setLog('Roadmap Builder: structuring learning phases and milestones');
  setAgent(2, 'done', 'Phase structure ready');

  setAgent(3, 'working', 'Curating resources');
  setProgress(60);
  await sleep(600);
  setLog('Resource Curator: finding videos, articles, projects & quizzes');
  setAgent(3, 'done', 'Resources curated');

  setAgent(4, 'working', 'Personalizing coaching');
  setProgress(80);
  await sleep(500);
  setLog('Progress Coach: setting checkpoints & adaptive rules');

  // ── Build roadmap and transition ──
  await buildRoadmap(topic, level, hours, goal);
}

/**
 * Generates roadmap data, streams a preview, then renders the roadmap screen.
 */
async function buildRoadmap(topic, level, hours, goal) {
  const streamEl = document.getElementById('streamed-output');
  streamEl.style.display = 'block';
  streamEl.textContent   = 'Building your roadmap...';

  // Generate from built-in templates
  roadmapData = generateRoadmap(topic, level, hours, goal);

  setAgent(4, 'done', 'Roadmap ready');
  setProgress(100);
  setLog('Your personalised roadmap is ready!');

  // Animate a streaming preview of the raw data
  const preview = JSON.stringify(roadmapData).slice(0, 120) + '...';
  let i = 0;
  await new Promise(resolve => {
    const interval = setInterval(() => {
      streamEl.textContent = preview.slice(0, i);
      i += 6;
      if (i > preview.length) {
        clearInterval(interval);
        setTimeout(() => {
          renderRoadmap();
          showScreen('screen-roadmap');
          resolve();
        }, 400);
      }
    }, 16);
  });
}

// Legacy alias kept for any inline onclick references in HTML
function callClaudeForRoadmap(topic, level, hours, goal) {
  return buildRoadmap(topic, level, hours, goal);
}
