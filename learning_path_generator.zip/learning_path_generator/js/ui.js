/**
 * ui.js
 * Screen navigation, agent loading animation, and shared UI helpers.
 */

// ── SCREEN NAVIGATION ─────────────────────────────────────────────────────────

function showScreen(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById(id).classList.add('active');
}

// ── AGENT CARD HELPERS ────────────────────────────────────────────────────────

/**
 * Update an agent card's visual state.
 * @param {number} n       Agent number (1-4)
 * @param {'idle'|'working'|'done'} state
 * @param {string} text    Status label text
 */
function setAgent(n, state, text) {
  const card   = document.getElementById('a' + n);
  const status = document.getElementById('a' + n + '-status');
  card.className = 'agent-card' +
    (state === 'working' ? ' working' : state === 'done' ? ' done' : '');
  if (state === 'working') {
    status.innerHTML = text + ' <span class="thinking-dots"><span>.</span><span>.</span><span>.</span></span>';
  } else {
    status.innerHTML = state === 'done' ? '✓ ' + text : text;
  }
}

/**
 * Show/update the agent log strip below the cards.
 * @param {string} text
 */
function setLog(text) {
  const el = document.getElementById('agent-log');
  el.style.display = 'flex';
  document.getElementById('agent-log-text').textContent = text;
}

/**
 * Update the generation progress bar.
 * @param {number} pct  0–100
 */
function setProgress(pct) {
  document.getElementById('gen-progress').style.width = pct + '%';
}
