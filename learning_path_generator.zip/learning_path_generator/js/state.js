/**
 * state.js — Shared application state
 * All mutable globals live here so every module can import them.
 */

let selectedGoal  = '';
let roadmapData   = null;
let completedTasks = new Set();
let totalTasks     = 0;
let userProfile    = {};

// Mentor / chat state
let currentPersona = 'coach';
let chatHistory    = [];

// ── PERSONAS ──────────────────────────────────────────────────────────────────
const PERSONAS = {
  coach:    { label: '🎯 Coach',          dot: '#5B3FE8' },
  socratic: { label: '🧠 Socratic',       dot: '#339AF0' },
  strict:   { label: '⚡ Drill Sergeant', dot: '#F59F00' },
  friendly: { label: '😊 Friend',         dot: '#12B886' },
  expert:   { label: '🔬 Expert',         dot: '#C2255C' }
};

// ── SUGGESTION SETS ───────────────────────────────────────────────────────────
const SUGGESTION_SETS = {
  early: ['Where should I start?', 'How many hours per day?', 'What is the hardest part?', 'Make me a daily schedule'],
  mid:   ['Am I on track?', 'I am feeling stuck', 'What to focus on next?', 'How to avoid burnout?'],
  late:  ['How do I prove my skills?', 'What for my portfolio?', 'How to prep for interviews?', 'What gaps should I fill?']
};

// ── OFFLINE RESPONSES ─────────────────────────────────────────────────────────
const RESPONSES = {
  default: [
    "Focus on the next task in Phase 1 and spend 25 minutes on it right now.",
    "Consistency beats intensity. Thirty minutes every day outperforms a three-hour Sunday session.",
    "The best resource for your level is the official documentation — bookmark it and refer back constantly.",
    "You are making progress. Every task you complete is compounding skill you did not have before.",
    "Struggling with something specific? Break it into the smallest possible step and do just that."
  ],
  stuck: [
    "Being stuck means you are at the edge of your current knowledge — that is exactly where learning happens.",
    "Take a 10-minute break, then return to the last thing that made sense and rebuild from there.",
    "Write down what you understand so far. The gap between that and what you need is your next learning target.",
    "Look for a simpler version of the problem. Solve that first, then scale back up."
  ],
  motivation: [
    "You already started, which puts you ahead of everyone who is still thinking about it.",
    "Progress is not linear. The messy middle is where real skill is forged.",
    "Think about why you started. That reason is still valid."
  ],
  schedule: [
    "For your hours, try: 20 min review, 30 min new content, 20 min practice — every session.",
    "Block your learning time in your calendar like a meeting. Treat it as non-negotiable.",
    "Three 30-minute sessions beat one 90-minute session for retention every time."
  ]
};

/**
 * Pick a relevant offline reply based on message keywords.
 * @param {string} msg
 * @returns {string}
 */
function getOfflineReply(msg) {
  const lower = msg.toLowerCase();
  if (/stuck|confus|don.t understand|hard|difficult/i.test(lower)) {
    return RESPONSES.stuck[Math.floor(Math.random() * RESPONSES.stuck.length)];
  }
  if (/motiv|tired|give up|worth|why/i.test(lower)) {
    return RESPONSES.motivation[Math.floor(Math.random() * RESPONSES.motivation.length)];
  }
  if (/schedule|plan|daily|routine|hours/i.test(lower)) {
    return RESPONSES.schedule[Math.floor(Math.random() * RESPONSES.schedule.length)];
  }
  return RESPONSES.default[Math.floor(Math.random() * RESPONSES.default.length)];
}
