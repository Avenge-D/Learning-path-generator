/**
 * chat.js
 * AI mentor chat: persona management, offline reply engine, Anthropic API call.
 */

// ── PERSONA MANAGEMENT ────────────────────────────────────────────────────────

function setPersona(btn) {
  document.querySelectorAll('.persona-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  currentPersona = btn.dataset.persona;
  const statusEl = document.getElementById('mentor-status-text');
  if (statusEl) statusEl.textContent = PERSONAS[currentPersona].label + ' is ready';
  const dot = document.getElementById('mentor-dot');
  if (dot) dot.style.background = PERSONAS[currentPersona].dot;
}

function clearChat() {
  const el = document.getElementById('chat-messages');
  if (!el) return;
  chatHistory = [];
  el.innerHTML = `<div class="msg msg-ai"><div class="msg-persona">${PERSONAS[currentPersona].label}</div>Chat cleared! What would you like to work on?</div>`;
}

// ── SUGGESTIONS ───────────────────────────────────────────────────────────────

function renderSuggestions() {
  const pct = totalTasks > 0 ? Math.round((completedTasks.size / totalTasks) * 100) : 0;
  const set = pct < 20 ? 'early' : pct < 70 ? 'mid' : 'late';
  const row = document.getElementById('suggestions-row');
  if (!row) return;
  row.innerHTML = '<span style="font-size:11px;color:var(--muted);align-self:center;">Try:</span>';
  SUGGESTION_SETS[set].forEach(s => {
    const chip = document.createElement('span');
    chip.className = 'suggestion-chip';
    chip.textContent = s;
    chip.onclick = () => { document.getElementById('chat-input').value = s; sendChat(); };
    row.appendChild(chip);
  });
}

// ── OFFLINE REPLY ENGINE ──────────────────────────────────────────────────────
/**
 * Full persona-native offline response system.
 * Falls back gracefully when the Anthropic API is unavailable.
 * @param {string} msg  Raw user message
 * @returns {string}
 */
function getOfflineReply(msg) {
  const m   = msg.toLowerCase().trim();
  const t   = userProfile.topic  || 'your subject';
  const pct = totalTasks > 0 ? Math.round((completedTasks.size / totalTasks) * 100) : 0;
  const hrs = userProfile.hours  || 'your available';
  const lvl = userProfile.level  || 'your current';
  const p   = currentPersona;

  // Derive next uncompleted task
  const nextTask = (() => {
    if (!roadmapData) return null;
    for (let pi = 0; pi < (roadmapData.phases || []).length; pi++)
      for (let ti = 0; ti < roadmapData.phases[pi].tasks.length; ti++)
        if (!completedTasks.has(`p${pi}t${ti}`)) return roadmapData.phases[pi].tasks[ti].title;
    return null;
  })();

  // ── Intent detection ──
  const isGreeting   = /^(hi+|hello+|hey+|howdy|hiya|sup|yo|good\s*(morning|evening|afternoon|night)|what'?s\s*up|how r u|greetings|namaste)\b/.test(m);
  const isThanks     = /thank|thanks|ty\b|thx|appreciate/.test(m);
  const isBye        = /bye|goodbye|see\s*ya|cya|later|take care/.test(m);
  const isWhoAreYou  = /who are you|what are you|what can you do|your name|introduce/.test(m);
  const isHowAreYou  = /how are you|how do you feel|you okay|u ok/.test(m);
  const isProgress   = /progress|how.*doing|percent|how far|on track|status/.test(m);
  const isStart      = /\b(start|begin|first step|where.*start|how to start|getting started)\b/.test(m);
  const isStuck      = /stuck|confused|lost|hard|difficult|don.?t (get|understand)|not sure|help me|struggling|can.?t figure/.test(m);
  const isMotivation = /motivat|burnout|tired|quit|give up|overwhelm|bored|lazy|procrastinat|demotivat/.test(m);
  const isSchedule   = /schedule|plan|daily|routine|time|how.*hours|when.*study|how long|how many hours/.test(m);
  const isNext       = /\b(next|what.*should i do|what.*focus|recommend|what to do)\b/.test(m);
  const isPortfolio  = /portfolio|project.*show|demo|github|deploy|publish|showcase/.test(m);
  const isInterview  = /interview|job|hire|recruiter|career|salary|resume|cv/.test(m);
  const isResource   = /resource|course|book|video|where.*learn|best.*learn|recommend.*course/.test(m);
  const isCompliment = /\b(great|awesome|amazing|love this|good app|cool app|nice|excellent|brilliant)\b/.test(m);

  // ── Response map by persona ──
  const R = {
    // ── COACH ──
    coach: {
      greeting:   `Hey, great to see you! You are working on ${t} and you are ${pct}% of the way through your roadmap. ${nextTask ? 'Your next task is "' + nextTask + '" — let\'s get you moving on that!' : 'You have completed all tasks — incredible work!'} What can I help you with today?`,
      thanks:     `You are welcome — that is what I am here for! Staying consistent with ${t} is the real win. What is your next challenge?`,
      bye:        `Go get it done! You have got real momentum with ${t}. Come back when you need a push. 💪`,
      whoAreYou:  `I am your AI learning coach for ${t}. I help you stay on track, work through roadblocks, and make sure your learning time actually turns into skill. What would you like to tackle?`,
      howAreYou:  `I am locked in and ready to help you with ${t}! More importantly — how are YOU doing? Are you making consistent progress or hitting any walls?`,
      progress:   pct === 0 ? `You are at 0% — let us fix that right now. Open "${nextTask || 'your first task'}" and spend 20 minutes on it. That is the entire goal for today.`
                : pct < 40 ? `${pct}% done — you are building foundations. Stay consistent and trust the process. "${nextTask || 'Your next task'}" is your immediate focus.`
                : pct < 80 ? `${pct}% through your ${t} roadmap — you are past the midpoint! This is where most people slow down, so now is the time to press. "${nextTask || 'Keep going!'}" is next.`
                :            `${pct}% done — you are in the final stretch. Do not coast. Finish strong and make sure your capstone project is solid.`,
      start:      nextTask ? `Start with "${nextTask}". Set a 25-minute timer, close distractions, and do just that. Momentum is built action by action — not by planning.`
                           : `You have finished all the structured tasks. Your next move is to build a real project with ${t} and put it somewhere public. That is how you prove the skill.`,
      stuck:      `Being stuck means you are at your learning edge — that is exactly the right place to be. Go back to the last concept that felt clear, then slowly work forward from there. You do not need to understand everything at once.`,
      motivation: `You chose to learn ${t} for a reason. Reconnect with that reason right now. Then do just 15 minutes — not the whole session, just 15 minutes. Action precedes motivation, not the other way around.`,
      schedule:   `With ${hrs} hours per week, aim for regular short sessions rather than marathon ones. Block specific times in your calendar — even 30 minutes daily compounds faster than you think.`,
      next:       nextTask ? `"${nextTask}" is your next task. Open it, read the tip, and start. Focus on one task at a time — not the whole roadmap.`
                           : `You have cleared the roadmap. Time to build something real with ${t}. A real project that you can show to people. That is your next assignment.`,
      portfolio:  `For your ${t} portfolio: two or three solid projects beat ten half-finished ones every time. Pick projects that solve real problems, deploy them, and write clear READMEs. Quality and specificity over quantity.`,
      interview:  `Prepare for ${t} interviews by knowing your own projects inside-out. Practice explaining your decisions out loud. Do 10 minutes of relevant problem practice daily. Your project stories are your strongest asset.`,
      resource:   `The resources in your roadmap are curated for your level. Depth in one good resource beats breadth across many. If something is not clicking, find a different explanation on YouTube — sometimes a different voice makes it land.`,
      compliment: `Thank you! The app only works if you do. What is your goal for today's learning session?`,
      default:    `Great question. At ${pct}% through ${t}${nextTask ? ', with "' + nextTask + '" up next' : ''}, the most important thing is to keep consistent forward momentum. What specifically would you like to work through?`
    },

    // ── SOCRATIC ──
    socratic: {
      greeting:   `Welcome. You are learning ${t} and are ${pct}% through your path. Before we begin — what do you already know about ${t}? And what do you feel most uncertain about? Understanding your mental model helps me ask better questions.`,
      thanks:     `That is kind. But the real question is: what did you learn from our exchange? What will you do differently as a result?`,
      bye:        `Before you go — what is the one thing you now understand about ${t} that you did not before? Hold onto that.`,
      whoAreYou:  `I am a Socratic learning guide for ${t}. Rather than giving you answers, I help you find them yourself through questions. What is the most confusing part of ${t} for you right now?`,
      howAreYou:  `I appreciate the question. More interestingly — how is your understanding of ${t} developing? What felt unclear last week that now makes sense?`,
      progress:   pct === 0 ? `You are at 0%. What, specifically, is stopping you from starting "${nextTask || 'your first task'}" today?`
                : pct < 50  ? `${pct}% done. Looking at what you have completed — what patterns are you noticing in how ${t} works? What surprised you?`
                :             `${pct}% complete. With the end in sight — what is the single most important insight you have gained about ${t} so far?`,
      start:      nextTask ? `"${nextTask}" is your next task. Before you open it — what do you already know or expect about this topic? Starting with your assumptions makes the learning far more powerful.`
                           : `You have completed all tasks. Now ask yourself: can you explain ${t} to someone who knows nothing about it? Where are the gaps in that explanation? Those gaps are your next frontier.`,
      stuck:      `Interesting. Instead of me explaining it — can you tell me exactly where your understanding breaks down? What is the last step that made sense? The answer often lives just past that boundary.`,
      motivation: `What is your real reason for learning ${t}? Not the surface answer — the deeper one. And what would it mean for you if you gave up now versus if you pushed through?`,
      schedule:   `What does your actual week look like right now? And what would a realistic — not ideal — learning schedule look like for ${t} given that reality? Let us design from what is true, not what is hypothetical.`,
      next:       nextTask ? `"${nextTask}" is next. But before you begin — what question would you most like that task to answer? Setting an intention before learning dramatically improves retention.`
                           : `You have finished the curriculum. What aspects of ${t} do you feel genuinely confident about? And where do you still feel uncertain? That uncertainty is your curriculum now.`,
      portfolio:  `What problem would you most want to solve with ${t}? And why that one? The answers to those questions will define a better portfolio project than any list I could give you.`,
      interview:  `In a ${t} interview, you will be asked to explain your decisions. So — for your most recent project, why did you make the choices you made? Practise justifying every decision. That habit will serve you well.`,
      resource:   `You have resources in your roadmap. Before seeking new ones — have you exhausted what is already there? What specifically is missing from those resources that you feel you need?`,
      compliment: `Thank you. But I am curious — what was the most useful thing you took from our conversation for your ${t} learning?`,
      default:    `Thoughtful question. Rather than answer directly — what do you think? What does your current understanding of ${t} suggest the answer might be? Start there, and I will help you refine it.`
    },

    // ── STRICT / DRILL SERGEANT ──
    strict: {
      greeting:   `You are here to learn ${t}. Good. You are ${pct}% done. ${pct === 0 ? 'That means you have not started yet. Unacceptable.' : pct < 50 ? 'Decent start. Do not slow down now.' : 'More than halfway. Finish what you started.'} What do you need?`,
      thanks:     `Save the thanks. Complete "${nextTask || 'your next task'}" and then thank yourself. Actions matter here, not words.`,
      bye:        `Do not just close this — go do something. Open "${nextTask || 'your next task'}" before you put the phone down. No excuses.`,
      whoAreYou:  `I am your drill sergeant for ${t}. No coddling, no excuses. You tell me what is blocking you and I tell you exactly how to remove it. What is the problem?`,
      howAreYou:  `Irrelevant. What matters is whether you completed "${nextTask || 'your last task'}". Did you? If not — that is the conversation. If yes — what is next?`,
      progress:   pct === 0 ? `Zero percent. Zero. Open "${nextTask || 'your first task'}" right now. This is not a suggestion.`
                : pct < 40  ? `${pct}% — fine, but you are still in the hard zone. Do not plateau here. "${nextTask || 'Your next task'}" is waiting. No rest until it is done.`
                : pct < 80  ? `${pct}% — you have got momentum, do not waste it. "${nextTask || 'Your next task'}" is waiting. Every hour you delay is an hour behind. Go.`
                :             `${pct}% — almost there. No coasting across the finish line. Complete "${nextTask || 'what remains'}" and make sure your final project is deployed and polished.`,
      start:      nextTask ? `No overthinking. Open "${nextTask}" right now. Set a 25-minute timer. Work until it rings. That is the start. Go.`
                           : `You have finished all tasks. Good. Now build a real project with ${t}, deploy it publicly, and write a README. That is your next order.`,
      stuck:      `Being stuck is not an excuse to stop. Break the problem into the smallest possible piece and solve just that. Confusion is temporary. Quitting is permanent. Push through.`,
      motivation: `You do not need motivation — you need discipline. Open "${nextTask || 'your task'}", work for 20 minutes, and motivation will follow the action. Stop waiting to feel ready.`,
      schedule:   `Here is your schedule — non-negotiable: same time every day, ${hrs} hours per week split into focused blocks, no phone, no distractions. Miss a day? Make it up the next day.`,
      next:       nextTask ? `"${nextTask}". That is what is next. Not tomorrow. Now. Complete it, mark it done, and come back.`
                           : `All tasks done. Now deploy a real project with ${t}. No more practice rounds — build something real and put it in front of people.`,
      portfolio:  `Your ${t} portfolio needs real projects — not toy tutorials. Two or three projects that solve actual problems, on GitHub, with at least one deployed live. Ship it.`,
      interview:  `${t} interviews reward preparation. Know your projects cold, practice explaining your decisions without notes. No shortcuts.`,
      resource:   `The resources are in your roadmap. Use them. Stop searching for the "perfect" course — it does not exist. Commit to what is in front of you and go deep.`,
      compliment: `Appreciated. Now stop admiring the tool and use it. Complete "${nextTask || 'your next task'}" before the end of today.`,
      default:    `Stop thinking and start doing. You are ${pct}% through ${t}. "${nextTask || 'Your next task'}" is waiting. What specifically are you going to do in the next 30 minutes?`
    },

    // ── FRIENDLY ──
    friendly: {
      greeting:   `Heyyy, so glad you are here! 😊 I am your friendly mentor for ${t} and honestly I am rooting for you so hard. You are already ${pct}% through your roadmap — that is genuinely cool! ${nextTask ? 'Your next step is "' + nextTask + '" — no pressure, just whenever you are ready!' : 'You have finished everything — that is amazing!'} What is on your mind?`,
      thanks:     `Aww, you are so welcome! Honestly helping you with ${t} is the highlight 😄 What else can I help you with? No question is too small, I promise!`,
      bye:        `Aww, take care! You are doing so well with ${t} and I genuinely mean that 💙 Come back anytime — even just to say hi. You have got this!`,
      whoAreYou:  `I am your friendly learning buddy for ${t}! Think of me as that one friend who actually knows this stuff and is always happy to help, zero judgement. Ask me literally anything 😄`,
      howAreYou:  `I am doing great, thanks for asking — that is so sweet! 😊 More importantly, how are YOU doing? Learning ${t} can be a lot sometimes. Tell me how you are really feeling!`,
      progress:   pct === 0 ? `Oh no worries at all that you have not started yet — everyone begins somewhere! Your first task is "${nextTask || 'Task 1'}" and it is totally doable, I promise. Just give it 20 minutes! 😊`
                : pct < 40  ? `${pct}% done — yay, you are on your way! 🎉 The beginning can feel slow but you are building real foundations in ${t}. Keep going!`
                : pct < 80  ? `${pct}%?! That is genuinely impressive — you should feel really good about that! 🌟 Keep riding this wave. "${nextTask || 'Your next task'}" is right there waiting!`
                :             `Oh wow, ${pct}% — you are SO close to finishing! 🙌 Just push through the last bit and imagine how great it will feel to say you mastered ${t}. Almost there!`,
      start:      nextTask ? `Okay so starting is actually the hardest part — and you have already done it by being here! 😄 Just open "${nextTask}" and give it 20 minutes. No pressure to be perfect!`
                           : `You have finished everything — I am genuinely so proud of you! 🎉 Now it is time to build something cool with ${t}. What kind of project sounds fun to you?`,
      stuck:      `Ugh, being stuck is the WORST feeling — but honestly? It means you are learning! 😊 Your brain is literally rewiring right now. Try a different explanation on YouTube — sometimes a fresh voice makes it click instantly. You are not stuck forever, I promise!`,
      motivation: `Hey, it is totally okay to feel this way — every learner does at some point! 💙 Here is a little trick: just commit to 10 minutes. Often you end up going way longer once you start. And remember why you chose ${t} — hold onto that!`,
      schedule:   `Okay let us make a schedule that actually works for you! With ${hrs} hours a week, shorter sessions more often — like 45 minutes daily — rather than big marathon sessions. Pick your best time of day and protect it! ☕`,
      next:       nextTask ? `Ooh, your next step is "${nextTask}" — it is a good one! Take it at your own pace, there is no rush. Complete it, check it off, and enjoy that little dopamine hit 😄`
                           : `You have done all the tasks — seriously, take a moment to appreciate that! 🥳 Now build something fun with ${t}. What idea have you been secretly thinking about?`,
      portfolio:  `Portfolio time is honestly my favourite part! For ${t}, think about building 2-3 projects that YOU would actually use — that passion shows through. Pop them on GitHub and deploy at least one. It feels so good to show people something real!`,
      interview:  `Interviews can feel scary but honestly you know more than you think! 😊 For ${t}, practice talking through your projects out loud — what you built, why, and what you learned. That storytelling is honestly more impressive than memorised answers. You have got this!`,
      resource:   `Okay so your roadmap already has great resources for ${t} — I would honestly stick with those rather than going down a rabbit hole looking for the "perfect" one (we have all been there 😄). Keep moving!`,
      compliment: `You are so sweet, thank you! 😊 The best way to make this app work for you is just using it consistently. What is your ${t} plan for today?`,
      default:    `Ooh great question! At ${pct}% through ${t}${nextTask ? ', with "' + nextTask + '" up next' : ''} — you are doing better than you probably think! 😊 Tell me more about what is on your mind!`
    },

    // ── EXPERT ──
    expert: {
      greeting:   `Welcome. You are working on ${t} at the ${lvl} level. You are currently ${pct}% through your learning path. ${nextTask ? 'Your next task is "' + nextTask + '", which sits in a critical part of the curriculum.' : 'You have completed all structured tasks.'} What specific area would you like to explore or clarify?`,
      thanks:     `Noted. The most effective use of our exchange is to address a specific gap in your ${t} understanding. What concept or skill would you like to dig into?`,
      bye:        `Before you go: the most valuable thing you can do now is apply what you have studied in ${t} to a real, unguided problem. Theory without application decays within days. Good luck.`,
      whoAreYou:  `I am an expert mentor with deep knowledge of ${t} pedagogy and industry practice. I focus on conceptual clarity and professional-grade thinking. What is the most nuanced question you have been sitting with?`,
      howAreYou:  `More usefully: how is your comprehension of ${t} actually holding up? Are there concepts you have passed but do not yet truly understand? That gap deserves our attention.`,
      progress:   pct === 0 ? `You are at 0% completion. The research on skill acquisition is clear: the biggest predictor of success is time-to-first-action. Open "${nextTask || 'your first task'}" now.`
                : pct < 40  ? `${pct}% complete. You are in the foundational phase — the highest-leverage learning period. The patterns you build now create the schema on which everything else hangs. Quality of understanding here is worth more than speed.`
                : pct < 80  ? `${pct}% through your ${t} roadmap. At this stage, the Dunning-Kruger inflection point is relevant — learners often overestimate their competence. Spend 20% of remaining sessions on retrieval practice of earlier material.`
                :             `${pct}% complete. In the final phase, the critical differentiator is not task completion but genuine transferable knowledge. Can you apply what you have learned in ${t} to a novel, unscripted problem?`,
      start:      nextTask ? `The optimal entry point is "${nextTask}". Before engaging with it, spend 5 minutes writing down what you already know or expect about the topic. This activates prior knowledge and dramatically improves retention.`
                           : `You have completed the structured curriculum. The next stage is unguided application: take a real-world problem in ${t} and solve it from scratch. That is where mastery is actually forged.`,
      stuck:      `Difficulty at this point in ${t} is diagnostically useful — it reveals the exact boundary of your current mental model. Try to articulate precisely where your understanding breaks down. Write it out. If still blocked, approach the concept from a different abstraction level — sometimes going up (broader context) or down (fundamental mechanics) resolves the blockage.`,
      motivation: `What you are experiencing is a well-documented phenomenon — motivational valleys typically occur at the 20-40% and 70-80% completion stages. The evidence-based prescription: reduce session length, increase frequency, and introduce a micro-project that produces immediate tangible output.`,
      schedule:   `With ${hrs} hours per week for ${t}, cognitive load research supports distributed practice: four shorter sessions outperform two longer ones in both retention and comprehension. Interleaving — mixing topics within a session — also outperforms block study for long-term retention.`,
      next:       nextTask ? `"${nextTask}" is the logical progression. Before advancing, verify mastery of current material: attempt to explain the last concept you studied to an imaginary listener without referencing your notes. Gaps in that explanation are your real next steps.`
                           : `With the structured curriculum complete, the next phase is deliberate project work. Choose a real-world application of ${t} that genuinely interests you. Specificity of motivation matters — projects from genuine curiosity produce measurably more engagement.`,
      portfolio:  `In the ${t} field, a portfolio is evaluated on: problem selection (did you solve something real?), execution quality (is the work clean and well-documented?), and communication (can you explain your decisions?). Two or three strong, deployed projects will outperform ten shallow tutorial replicas.`,
      interview:  `${t} technical interviews assess pattern recognition, not memorisation. The highest-value preparation: deeply understand your own projects (be ready to defend every decision), practice explaining complex concepts simply, and study the 15-20 foundational questions that recur most frequently. Mock interviews reduce performance anxiety significantly.`,
      resource:   `Your roadmap resources were curated for your level in ${t}. The research is unambiguous: depth in one high-quality resource significantly outperforms breadth across many. Resist the impulse to switch resources when you encounter difficulty — difficulty is the signal that learning is occurring.`,
      compliment: `Thank you. The most meaningful indicator of value will be whether your ${t} competence measurably improves. To that end — what is the most challenging concept in your current phase, and how confident are you in your understanding of it?`,
      default:    `Substantive question. At ${pct}% through ${t}${nextTask ? ', with "' + nextTask + '" as your next task' : ''}, the most leveraged question to ask yourself is: what do I understand well enough to teach, and what do I merely recognise? That distinction separates surface familiarity from genuine expertise.`
    }
  };

  // Route to the right response
  const persona = R[p] || R.coach;
  if (isGreeting)   return persona.greeting;
  if (isThanks)     return persona.thanks;
  if (isBye)        return persona.bye;
  if (isWhoAreYou)  return persona.whoAreYou;
  if (isHowAreYou)  return persona.howAreYou;
  if (isProgress)   return persona.progress;
  if (isStart)      return persona.start;
  if (isStuck)      return persona.stuck;
  if (isMotivation) return persona.motivation;
  if (isSchedule)   return persona.schedule;
  if (isNext)       return persona.next;
  if (isPortfolio)  return persona.portfolio;
  if (isInterview)  return persona.interview;
  if (isResource)   return persona.resource;
  if (isCompliment) return persona.compliment;
  return persona.default;
}

// ── SEND CHAT ─────────────────────────────────────────────────────────────────

async function sendChat() {
  const input     = document.getElementById('chat-input');
  const msg       = input.value.trim();
  if (!msg) return;
  input.value = '';

  const messagesEl = document.getElementById('chat-messages');
  const btn        = document.getElementById('chat-send-btn');
  const dot        = document.getElementById('mentor-dot');
  const statusEl   = document.getElementById('mentor-status-text');

  btn.disabled = true;
  if (dot)      dot.classList.add('thinking');
  if (statusEl) statusEl.textContent = PERSONAS[currentPersona].label + ' is thinking...';

  // User bubble
  const userDiv = document.createElement('div');
  userDiv.className   = 'msg msg-user';
  userDiv.textContent = msg;
  messagesEl.appendChild(userDiv);

  // Typing indicator
  const typingDiv = document.createElement('div');
  typingDiv.className = 'msg msg-ai';
  typingDiv.innerHTML = '<span class="thinking-dots"><span>.</span><span>.</span><span>.</span></span>';
  messagesEl.appendChild(typingDiv);
  messagesEl.scrollTop = messagesEl.scrollHeight;

  // Build system prompt
  const pct = totalTasks > 0 ? Math.round((completedTasks.size / totalTasks) * 100) : 0;
  const nextTask = (() => {
    if (!roadmapData) return null;
    for (let pi = 0; pi < (roadmapData.phases || []).length; pi++)
      for (let ti = 0; ti < roadmapData.phases[pi].tasks.length; ti++)
        if (!completedTasks.has('p' + pi + 't' + ti)) return roadmapData.phases[pi].tasks[ti].title;
    return null;
  })();

  const personaInstructions = {
    coach:    'You are an encouraging, goal-oriented learning coach. Give actionable, specific advice. Celebrate small wins.',
    socratic: 'You are a Socratic mentor. Guide with questions first, then give answers. Make the learner think.',
    strict:   'You are a no-nonsense drill sergeant mentor. Be direct, blunt, and hold the learner accountable. No fluff.',
    friendly: 'You are a warm, casual friend who is great at teaching. Be fun, encouraging, and use light humour.',
    expert:   'You are a seasoned domain expert and educator. Give deep, nuanced, industry-aligned guidance.'
  };

  const systemPrompt = `You are an AI learning mentor embedded in a learning path app.

Student profile:
- Learning: ${userProfile.topic || 'a new skill'}
- Level: ${userProfile.level || 'beginner'}
- Hours per week: ${userProfile.hours || 'flexible'}
- Goal: ${userProfile.goal || 'personal growth'}
- Progress: ${completedTasks.size}/${totalTasks} tasks done (${pct}%)
- Next task: ${nextTask || 'all complete!'}

Your persona: ${personaInstructions[currentPersona] || personaInstructions.coach}

Rules: Keep replies to 2-4 sentences unless detail is truly needed. Be specific to the learner's topic. No markdown symbols (* # ** etc). Plain conversational text only. Handle greetings, small talk, and motivation warmly.`;

  chatHistory.push({ role: 'user', content: msg });
  if (chatHistory.length > 20) chatHistory = chatHistory.slice(-20);

  // ── Try Anthropic API first ──
  let replied = false;
  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 400,
        system: systemPrompt,
        messages: chatHistory
      })
    });

    if (response.ok) {
      const data  = await response.json();
      const reply = (data.content || []).map(b => b.type === 'text' ? b.text : '').join('').trim();
      if (reply) {
        chatHistory.push({ role: 'assistant', content: reply });
        typingDiv.innerHTML = '<div class="msg-persona">' + PERSONAS[currentPersona].label + '</div>' + reply;
        replied = true;
      }
    }
  } catch(e) { /* fall through to offline */ }

  // ── Offline fallback ──
  if (!replied) {
    await new Promise(r => setTimeout(r, 600 + Math.random() * 400));
    const offlineReply = getOfflineReply(msg);
    chatHistory.push({ role: 'assistant', content: offlineReply });
    typingDiv.innerHTML = '<div class="msg-persona">' + PERSONAS[currentPersona].label + ' <span style="font-size:9px;opacity:.4;font-weight:400;">offline</span></div>' + offlineReply;
  }

  btn.disabled = false;
  if (dot)      dot.classList.remove('thinking');
  if (statusEl) statusEl.textContent = PERSONAS[currentPersona].label + ' is ready';
  messagesEl.scrollTop = messagesEl.scrollHeight;
  renderSuggestions();
}
