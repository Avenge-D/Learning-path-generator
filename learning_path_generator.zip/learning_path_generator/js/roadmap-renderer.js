/**
 * roadmap-renderer.js
 * All DOM rendering for the roadmap, progress, and adaptive path screens.
 */

// ── RENDER ROADMAP ────────────────────────────────────────────────────────────
function renderRoadmap() {
  if (!roadmapData) return;
  document.getElementById('roadmap-title').textContent = roadmapData.title || 'Your Learning Path';

  // Meta badges
  const metaEl = document.getElementById('roadmap-meta');
  metaEl.innerHTML = `
    <span class="meta-badge">⏱ ${roadmapData.totalWeeks || '12'} weeks</span>
    <span class="meta-badge">🎯 ${userProfile.goal}</span>
    <span class="meta-badge">📅 ${userProfile.hours} hrs/week</span>
    <span class="meta-badge">📊 ${userProfile.level}</span>
  `;

  const container = document.getElementById('phases-container');
  container.innerHTML = '';
  totalTasks = 0;

  if (roadmapData.insight) {
    container.innerHTML += `<div class="insight-card"><span class="insight-icon">💡</span><span>${roadmapData.insight}</span></div>`;
  }

  (roadmapData.phases || []).forEach((phase, pi) => {
    const phaseEl = document.createElement('div');
    phaseEl.className = 'phase-block';
    const tasks = (phase.tasks || []);
    totalTasks += tasks.length;

    // Phase header
    const header = document.createElement('div');
    header.className = 'phase-header';
    header.innerHTML = `
      <div class="phase-num">${phase.phase || pi+1}</div>
      <div>
        <div class="phase-title">${phase.title || 'Phase ' + (pi+1)}</div>
        <div class="task-meta">${phase.objective || ''}</div>
      </div>
      <span class="phase-duration">${phase.duration || ''}</span>
    `;
    phaseEl.appendChild(header);

    // Tasks list
    const tasksList = document.createElement('div');
    tasksList.className = 'tasks-list';

    tasks.forEach((t, ti) => {
      const taskId   = 'p' + pi + 't' + ti;
      const typeClass = 'type-' + (t.type || 'article');
      const topic    = userProfile.topic || '';
      const ytQuery  = encodeURIComponent(t.title + ' ' + topic + (t.type === 'video' ? '' : ' tutorial'));
      const ytUrl    = 'https://www.youtube.com/results?search_query=' + ytQuery;

      // Task wrapper
      const taskEl = document.createElement('div');
      taskEl.className = 'task-item';
      taskEl.id = taskId;

      // Checkbox
      const checkEl = document.createElement('div');
      checkEl.className = 'task-check';
      checkEl.id = taskId + '-check';
      checkEl.innerHTML = `<svg width="10" height="8" viewBox="0 0 10 8" fill="none" style="display:none" id="${taskId}-tick">
        <path d="M1 4L3.5 6.5L9 1" stroke="white" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>`;

      // Content
      const contentEl = document.createElement('div');
      contentEl.className = 'task-content';

      const titleEl = document.createElement('div');
      titleEl.className = 'task-title';
      titleEl.innerHTML = `${t.title}<span class="task-type-badge ${typeClass}">${t.type || 'article'}</span>`;

      const metaEl2 = document.createElement('div');
      metaEl2.className = 'task-meta';
      metaEl2.textContent = (t.duration || '') + ' · ' + (t.resource || '');

      const tipEl = document.createElement('div');
      tipEl.className = 'task-meta';
      tipEl.style.cssText = 'color:var(--accent);margin-top:2px';
      tipEl.textContent = '💬 ' + (t.tip || '');

      // YouTube button
      const ytBtn = document.createElement('button');
      ytBtn.className = 'yt-btn';
      ytBtn.type = 'button';
      ytBtn.style.cssText = 'position:relative;z-index:99;pointer-events:all;display:inline-flex;align-items:center;gap:5px;margin-top:7px;cursor:pointer;border:none;';
      ytBtn.innerHTML = `<svg width="13" height="9" viewBox="0 0 13 9" fill="none"><path d="M12.3 1.4a1.6 1.6 0 0 0-1.1-1.1C10.2 0 6.5 0 6.5 0S2.8 0 1.8.3A1.6 1.6 0 0 0 .7 1.4C.4 2.4.4 4.5.4 4.5s0 2.1.3 3.1a1.6 1.6 0 0 0 1.1 1.1C2.8 9 6.5 9 6.5 9s3.7 0 4.7-.3a1.6 1.6 0 0 0 1.1-1.1c.3-1 .3-3.1.3-3.1s0-2.1-.3-3.1z" fill="#fff"/><path d="M5.3 6.4V2.6L8.6 4.5 5.3 6.4z" fill="#FF0000"/></svg>Search on YouTube`;

      ytBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        e.preventDefault();
        let opened = false;

        // Method 1: sendPrompt (Claude artifact)
        try {
          if (typeof sendPrompt === 'function') {
            sendPrompt('Open this YouTube search link for me: ' + ytUrl);
            opened = true;
          }
        } catch(err) {}

        // Method 2: window.open
        if (!opened) {
          try {
            const w = window.open(ytUrl, '_blank', 'noopener,noreferrer');
            if (w) { w.focus(); opened = true; }
          } catch(err) {}
        }

        // Method 3: top-level frame
        if (!opened) {
          try {
            if (window.top && window.top !== window) {
              window.top.location.href = ytUrl;
              opened = true;
            }
          } catch(err) {}
        }

        // Method 4: same-tab fallback
        if (!opened) {
          try { window.location.href = ytUrl; opened = true; } catch(err) {}
        }

        // Method 5: toast with copyable link
        if (!opened) {
          try { navigator.clipboard.writeText(ytUrl).catch(() => {}); } catch(err) {}
          showYtToast(ytUrl);
        }
      });

      contentEl.appendChild(titleEl);
      contentEl.appendChild(metaEl2);
      contentEl.appendChild(tipEl);
      contentEl.appendChild(ytBtn);
      taskEl.appendChild(checkEl);
      taskEl.appendChild(contentEl);

      // Toggle on click (but not if YouTube button was clicked)
      taskEl.addEventListener('click', function(e) {
        if (e.target.closest('.yt-btn')) return;
        toggleTask(taskId);
      });

      tasksList.appendChild(taskEl);
    });

    phaseEl.appendChild(tasksList);
    container.appendChild(phaseEl);
  });

  renderProgress();
  renderSuggestions();
}

// ── YOUTUBE TOAST ─────────────────────────────────────────────────────────────
function showYtToast(url) {
  const existing = document.getElementById('yt-toast');
  if (existing) existing.remove();

  const toast = document.createElement('div');
  toast.id = 'yt-toast';
  toast.style.cssText = 'position:fixed;bottom:24px;left:50%;transform:translateX(-50%);background:#1C1C2E;border:1px solid #FF0000;border-radius:12px;padding:12px 16px;z-index:9999;max-width:90vw;box-shadow:0 4px 24px rgba(0,0,0,0.5);';
  toast.innerHTML =
    '<div style="font-size:12px;color:#F0F0F5;margin-bottom:8px;font-weight:600;">📺 Open YouTube Search</div>' +
    '<div style="font-size:11px;color:#8888A8;margin-bottom:10px;word-break:break-all;">' + url + '</div>' +
    '<div style="display:flex;gap:8px;">' +
      '<button onclick="navigator.clipboard.writeText(\'' + url + '\').then(()=>{this.textContent=\'Copied!\';setTimeout(()=>this.textContent=\'Copy Link\',1500)})" ' +
        'style="flex:1;background:#2E2E48;border:1px solid #2E2E48;border-radius:8px;padding:6px 10px;font-size:12px;color:#F0F0F5;cursor:pointer;">Copy Link</button>' +
      '<button onclick="document.getElementById(\'yt-toast\').remove()" ' +
        'style="background:transparent;border:1px solid #2E2E48;border-radius:8px;padding:6px 10px;font-size:12px;color:#8888A8;cursor:pointer;">✕</button>' +
    '</div>';

  document.body.appendChild(toast);
  setTimeout(() => {
    const t = document.getElementById('yt-toast');
    if (t) t.remove();
  }, 8000);
}

// ── TOGGLE TASK ───────────────────────────────────────────────────────────────
function toggleTask(id) {
  const item = document.getElementById(id);
  const tick = document.getElementById(id + '-tick');
  if (completedTasks.has(id)) {
    completedTasks.delete(id);
    item.classList.remove('completed');
    tick.style.display = 'none';
  } else {
    completedTasks.add(id);
    item.classList.add('completed');
    tick.style.display = 'block';
  }
  renderProgress();
}

// ── RENDER PROGRESS ───────────────────────────────────────────────────────────
function renderProgress() {
  const pct = totalTasks > 0 ? Math.round((completedTasks.size / totalTasks) * 100) : 0;
  const el  = document.getElementById('progress-content');
  el.innerHTML = `
    <div style="margin-bottom:1rem;">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
        <span style="font-family:var(--syne);font-size:15px;font-weight:700;color:var(--text)">Overall Progress</span>
        <span style="font-size:22px;font-family:var(--syne);font-weight:700;color:var(--accent)">${pct}%</span>
      </div>
      <div class="progress-strip" style="height:10px;"><div class="progress-fill" style="width:${pct}%"></div></div>
      <div style="font-size:12px;color:var(--muted);margin-top:6px;">${completedTasks.size} of ${totalTasks} tasks completed</div>
    </div>
    <div class="form-card" style="margin-top:1rem;">
      <div style="font-family:var(--syne);font-size:14px;font-weight:700;margin-bottom:8px;">Phase Summary</div>
      ${(roadmapData.phases || []).map((p, pi) => {
        const ptasks = (p.tasks || []).map((_, ti) => `p${pi}t${ti}`);
        const done   = ptasks.filter(id => completedTasks.has(id)).length;
        const ppct   = ptasks.length > 0 ? Math.round((done / ptasks.length) * 100) : 0;
        return `<div style="margin-bottom:10px;">
          <div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:4px;">
            <span>${p.title}</span><span style="color:var(--accent-2);font-weight:500;">${ppct}%</span>
          </div>
          <div class="progress-strip"><div class="progress-fill" style="width:${ppct}%"></div></div>
        </div>`;
      }).join('')}
    </div>
  `;
}

// ── ADAPT PATH ────────────────────────────────────────────────────────────────
function adaptPath() {
  if (!roadmapData) return;
  const pct       = totalTasks > 0 ? Math.round((completedTasks.size / totalTasks) * 100) : 0;
  const container = document.getElementById('phases-container');
  const existing  = container.querySelector('.adapt-card');
  if (existing) existing.remove();

  let advice;
  if (pct === 0) {
    advice = { insight: "You haven't started yet — that's the only thing to fix.", adjustment: "Open your first task right now and spend 20 minutes on it. Everything else follows from that." };
  } else if (pct < 30) {
    advice = { insight: "You're in the hardest stretch — the beginning, where habits aren't formed yet.", adjustment: "Focus only on Phase 1. Don't look ahead. Complete one task per session, nothing more." };
  } else if (pct < 60) {
    advice = { insight: "You've built real momentum — this is where most people plateau.", adjustment: "Increase your session length by 15 minutes and start applying concepts in a small side project." };
  } else if (pct < 85) {
    advice = { insight: "You're in the home stretch — the skills are forming fast now.", adjustment: "Spend 20% of your time reviewing earlier phases. Retrieval practice cements knowledge." };
  } else {
    advice = { insight: "Almost done — don't coast across the finish line.", adjustment: "Focus on your capstone project and make sure it's deployed and shareable before you call it complete." };
  }

  const el = document.createElement('div');
  el.className = 'insight-card adapt-card';
  el.style.cssText = 'background:#0A2B22;border-color:var(--accent-2);color:#0ECC8C;margin-bottom:1rem;';
  el.innerHTML = `<span class="insight-icon">🔄</span><div><strong>Adaptive Update (${pct}% done):</strong> ${advice.insight}<br><span style="opacity:.8;margin-top:4px;display:block;">${advice.adjustment}</span></div>`;
  container.insertBefore(el, container.firstChild);
}

// ── SWITCH TAB ────────────────────────────────────────────────────────────────
function switchTab(tab) {
  document.querySelectorAll('.tab').forEach((t, i) => {
    const tabs = ['roadmap', 'chat', 'progress'];
    t.classList.toggle('active', tabs[i] === tab);
  });
  document.getElementById('tab-roadmap').style.display  = tab === 'roadmap'  ? 'block' : 'none';
  document.getElementById('tab-chat').style.display     = tab === 'chat'     ? 'block' : 'none';
  document.getElementById('tab-progress').style.display = tab === 'progress' ? 'block' : 'none';
  if (tab === 'progress') renderProgress();
  if (tab === 'chat')     renderSuggestions();
}
