# Autonomous Learning Path Generator
### Source Code Reference

This folder contains the fully separated source code extracted from
`autonomous_learning_path_generator__.html`.

---

## Folder Structure

```
learning_path_generator/
├── index.html                  ← Main HTML entry point (screens & markup)
│
├── css/
│   ├── variables.css           ← Design tokens, CSS custom properties, Google Fonts import
│   ├── base.css                ← Reset, layout, shared components (buttons, tabs, progress)
│   ├── hero.css                ← Hero banner, animated orbs, eyebrow, stats, agent pills
│   ├── forms.css               ← Form cards, inputs, selects, goal chips
│   ├── roadmap.css             ← Phase blocks, task items, type badges, YouTube button
│   ├── chat.css                ← Mentor chat, persona buttons, status bar, suggestions
│   └── responsive.css          ← Media queries (≤480px, ≤360px), touch targets, iOS fixes
│
└── js/
    ├── state.js                ← Shared mutable state & constants (personas, suggestions)
    ├── roadmap-generator.js    ← Pure data: generates roadmap object from user profile
    ├── roadmap-renderer.js     ← DOM renderer: phases, tasks, progress bar, adapt path
    ├── chat.js                 ← Mentor chat: persona routing, offline reply engine, API call
    ├── ui.js                   ← Screen navigation, agent card animation helpers
    └── main.js                 ← Entry point: event listeners, generation flow orchestration
```

---

## Languages Used

| Language   | Files                       | Role                                     |
|------------|-----------------------------|------------------------------------------|
| HTML5      | `index.html`                | Structure, screens, semantic markup      |
| CSS3       | `css/*.css` (7 files)       | Styling, animations, responsive layout   |
| JavaScript | `js/*.js` (6 files)         | App logic, AI API integration, DOM manipulation |

---

## Key Technologies & APIs

- **Anthropic Claude API** (`claude-sonnet-4-20250514`) — AI mentor chat responses
- **Google Fonts** — Outfit (display) + Space Grotesk (body) + Noto Color Emoji
- **Noto Emoji (woff2)** — Cross-platform emoji font fallback
- **CSS custom properties** — Full design token system in `variables.css`
- **CSS animations** — Grid drift, orb pulse, gradient slide, fade-up transitions
- **Fetch API** — Anthropic `/v1/messages` endpoint with graceful offline fallback
- **YouTube search integration** — Multi-method URL opener with clipboard fallback

---

## How to Run

Open `index.html` in any modern browser. No build step required — pure HTML/CSS/JS.

> **Note:** The AI mentor chat calls the Anthropic API directly from the browser.
> This works in Claude's artifact environment where the API key is injected automatically.
> For local development you would need to proxy the API call through a backend.

---

## Architecture Overview

```
User Input (index.html)
       │
       ▼
main.js ──► state.js (shared state)
       │
       ├──► ui.js           (screen transitions, agent card animation)
       │
       ├──► roadmap-generator.js  (pure function: profile → roadmap data)
       │
       ├──► roadmap-renderer.js   (roadmap data → DOM, task toggle, progress)
       │
       └──► chat.js               (persona management, offline AI, Anthropic API)
```

---

## Offline Fallback

The app works fully offline. When the Anthropic API is unavailable, `chat.js`
falls back to a built-in persona-native response engine that routes user messages
by intent (greeting, stuck, motivation, schedule, progress, etc.) and replies
with persona-appropriate text for all 5 mentor personalities.
